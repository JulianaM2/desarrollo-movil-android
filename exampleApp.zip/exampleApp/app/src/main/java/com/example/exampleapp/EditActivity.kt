package com.example.exampleapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.EditText

class EditActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }

    fun saveNote(view: View) {
        val intent = Intent(this, DisplayNoteActivity::class.java)
        val editText = findViewById<EditText>(R.id.edit_message)
        val message = editText.text.toString()
        intent.putExtra("nota1", message)
        startActivity(intent)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        finish()
        return super.onOptionsItemSelected(item)
    }
}